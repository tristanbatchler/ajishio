import asyncio
import pygame
import ajishio as aj
aj.room_set_caption('Hello, World!')
asyncio.run(aj.game_start_async())