from typing import Protocol

from websockets.asyncio.server import ServerConnection
from demo_projects.moonlapse.server.client import Client
from demo_projects.moonlapse.shared.packets.clientbound import ClientboundPacket


class HubLike(Protocol):
    async def register_client(self, ws: ServerConnection) -> None: ...
    def unregister_client(self, client_id: int) -> Client | None: ...
    def get_clients(self) -> list[Client]: ...
    async def send_to(self, client_id: int, packet: ClientboundPacket) -> None: ...
    async def broadcast(
        self,
        packet: ClientboundPacket,
        except_for: int | None = None,
    ) -> None: ...
