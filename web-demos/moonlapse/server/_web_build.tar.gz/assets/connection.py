from __future__ import annotations

import asyncio
import logging
from collections.abc import Set

import aiosqlite
from websockets.asyncio.server import ServerConnection
from demo_projects.moonlapse.shared.packets import clientbound, deserialize_from_client
from demo_projects.moonlapse.shared.constants import TICKS_PER_SECOND
from demo_projects.moonlapse.server.client import Client
from demo_projects.moonlapse.server.states import ConnectedState
from demo_projects.moonlapse.shared.world import World

log = logging.getLogger("moonlapse.connection")


class Hub:
    def __init__(self, db_conn: aiosqlite.Connection) -> None:
        self._next_client_id: int = 1
        self._next_entity_id: int = 1
        self._clients: dict[int, Client] = {}
        self.db_conn: aiosqlite.Connection = db_conn
        self.tick_rate: float = 1 / TICKS_PER_SECOND
        self.world: World = (
            World()
        )  # TODO: A world loader is needed eventually to load all entities in the DB

    @property
    def next_client_id(self) -> int:
        cid = self._next_client_id
        self._next_client_id += 1
        return cid

    @property
    def next_entity_id(self) -> int:
        eid = self._next_entity_id
        self._next_entity_id += 1
        return eid

    def unregister_client(self, client_id: int) -> Client | None:
        return self._clients.pop(client_id, None)

    def get_clients(self) -> list[Client]:
        return list(self._clients.values())

    async def register_client(self, ws: ServerConnection) -> None:
        cid = self.next_client_id
        client = Client(cid, ws)
        self._clients[cid] = client
        await client.change_state(ConnectedState(client, self))

        try:
            async for raw in client.ws:
                data = raw if isinstance(raw, bytes) else raw.encode()
                packet = deserialize_from_client(data)
                await client.input_packet_queue.put(packet)

        except Exception as exc:
            log.info("client %d disconnected: %s", cid, exc)

        finally:
            _ = self.unregister_client(cid)
            await self.broadcast(clientbound.ClientDisconnected(cid))
            log.info(
                f"disconnected {cid} ({client.ip_address}), total={len(self.get_clients())}"
            )

    async def run(self) -> None:
        loop = asyncio.get_running_loop()
        next_tick = loop.time()

        while True:
            next_tick += self.tick_rate
            await asyncio.sleep(max(0, next_tick - loop.time()))
            await self.tick()

    async def tick(self) -> None:
        for client in self.get_clients():
            if client.state is None:
                continue

            while not client.input_packet_queue.empty():
                packet = await client.input_packet_queue.get()
                new_state = await client.state.handle_packet(packet)

                if new_state is not None:
                    await client.change_state(new_state)

    async def send_client_ws(
        self, client_id: int, packet: clientbound.ClientboundPacket
    ) -> None:
        session = self._clients.get(client_id)
        if session is not None:
            try:
                await session.ws.send(packet.serialize())
            except Exception as exc:
                log.warning(f"send_to {client_id} failed: {exc}")

    async def broadcast(
        self,
        packet: clientbound.ClientboundPacket,
        only_to: Set[int] | None = None,
        except_for: Set[int] | None = None,
    ) -> None:
        if only_to is None:
            only_to = self._clients.keys()
        if except_for is None:
            except_for = set()
        recipients = only_to - except_for
        for cid in recipients:
            client = self._clients[cid]
            try:
                await client.ws.send(packet.serialize())
            except Exception as exc:
                log.warning(f"broadcast failed to {cid}: {exc}")

    async def close(self) -> None:
        await self.db_conn.close()
