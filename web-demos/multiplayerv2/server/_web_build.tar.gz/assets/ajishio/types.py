from __future__ import annotations
from typing import Protocol, TypedDict, runtime_checkable
from collections.abc import Sequence
from uuid import UUID
from pygame import Surface
from dataclasses import dataclass

type CustomFields = dict[str, object]


@dataclass
class CollisionMask:
    bbleft: float = 0
    bbtop: float = 0
    bbright: float = 0
    bbbottom: float = 0


@dataclass
class GameSprite:
    images: Sequence[Surface]
    width: int
    height: int
    x_offset: float = 0.0
    y_offset: float = 0.0


class Entity(TypedDict):
    x: float
    y: float
    iid: str
    width: int
    height: int
    sprite_index: GameSprite | None
    collision_mask: CollisionMask | None
    customFields: CustomFields


class GameObjectKwargs(TypedDict, total=False):
    sprite_index: GameSprite | None
    collision_mask: CollisionMask | None
    iid: str | None
    width: float
    height: float
    customFields: CustomFields | None


@dataclass
class GameLevel:
    tilemaps: dict[str, list[list[bool]]]
    tile_sizes: dict[str, tuple[int, int]]
    background_surfaces: dict[str, Surface]
    level_size: tuple[int, int]
    entities: dict[str, Sequence[Entity]]


@runtime_checkable
class IGameObject(Protocol):
    persistent: bool
    id: UUID
    x: float
    y: float
    sprite_index: GameSprite | None
    image_index: int
    image_speed: float
    image_xscale: float
    image_yscale: float
    collision_mask: CollisionMask | None
    depth: int
    iid: str | None
    width: float
    height: float
    custom_fields: CustomFields

    @property
    def sprite_width(self) -> int: ...

    @property
    def sprite_height(self) -> int: ...

    @classmethod
    def create_from_entity(cls, _entity: Entity) -> IGameObject: ...

    def step(self) -> None: ...

    def draw(self) -> None: ...

    def on_game_end(self) -> None: ...

    def place_meeting(
        self, _x: float, _y: float, _obj: IGameObject | type[IGameObject] | UUID
    ) -> IGameObject | None: ...

    def on_destroy(self) -> None:
        """
        This event is the event to be executed when an instance is destroyed. It is often overlooked
        when adding behaviours to objects, but it can be very useful, for example by creating
        explosion or particle effects when an enemy is killed, or for respawning a new instance of
        the object in another part of the room, or even for adding points to a score.
        """
        ...
