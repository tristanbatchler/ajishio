import pygame
'Multiplayerv2 chat server — binary packet protocol.\n\nAssigns each connecting client a unique UUID, then relays Chat packets\nto all connected clients.  Responds to Ping with Pong.\n'
import asyncio
from uuid import UUID, uuid4
import websockets
from websockets.asyncio.server import ServerConnection
from demo_projects.multiplayerv2.shared.packets import AssignId, Chat, ClientConnected, ClientDisconnected, Packet, Ping, Pong, decode
HOST = '0.0.0.0'
PORT = 8765
_clients: dict[ServerConnection, UUID] = {}

async def broadcast(message: str, *, exclude: ServerConnection | None=None) -> None:
    for ws in list(_clients):
        if ws is exclude:
            continue
        try:
            await ws.send(message)
        except Exception as exc:
            print(f'SERVER: broadcast error to {ws.remote_address}: {exc}')

async def handle(ws: ServerConnection) -> None:
    sender_id = uuid4()
    _clients[ws] = sender_id
    addr = ws.remote_address
    print(f'SERVER: connected {addr} as {sender_id.hex[:8]}, total={len(_clients)}')
    await ws.send(AssignId(sender_id=sender_id).encode())
    await broadcast(ClientConnected(client_id=sender_id).encode(), exclude=ws)
    try:
        async for message in ws:
            if isinstance(message, bytes):
                message = message.decode('utf-8', 'replace')
            pkt: Packet | None = decode(message.encode('utf-8'))
            if pkt is None:
                print(f'SERVER: malformed packet from {sender_id.hex[:8]}')
                continue
            if isinstance(pkt, Chat):
                print(f'SERVER: chat from {sender_id.hex[:8]}: {pkt.text!r}')
                out = Chat(sender_id=sender_id, text=pkt.text).encode()
                await broadcast(out)
            elif isinstance(pkt, Ping):
                print(f'SERVER: ping from {sender_id.hex[:8]} token={pkt.token}')
                await ws.send(Pong(token=pkt.token).encode())
            else:
                print(f'SERVER: unexpected packet type from {sender_id.hex[:8]}: {pkt}')
    except Exception as exc:
        print(f'SERVER: handler error: {exc}')
    finally:
        _ = _clients.pop(ws, None)
        print(f'SERVER: disconnected {sender_id.hex[:8]} {addr}, total={len(_clients)}')
        await broadcast(ClientDisconnected(client_id=sender_id).encode())

async def main() -> None:
    async with websockets.serve(handle, HOST, PORT):
        print(f'chat server on {HOST}:{PORT}')
        await asyncio.Future()
asyncio.run(main())