from __future__ import annotations

import asyncio
from collections.abc import Container, Iterable, Callable
from logging import Logger
from pathlib import Path
from typing import TYPE_CHECKING, cast
from uuid import UUID
from ajishio.input import input
from ajishio.view import view
from ajishio.types import CollisionMask, GameLevel, IGameObject, GameSprite
from ajishio.rendering import Renderer, Color, c_white
import ajishio.pyqtree as pyqtree
import pygame as pg
import sys
import logging

if TYPE_CHECKING:
    from ajishio.game_sound import GameSound


epsilon: float = 0.00001


def set_window_icon() -> None:
    """Best-effort window icon setup for desktop and web runtimes."""
    engine_dir = Path(__file__).parent.parent.parent
    icon_path = engine_dir / "assets" / "logo.png"
    logger = logging.getLogger(__name__)
    try:
        icon_surface = pg.image.load(icon_path).convert_alpha()
        # Most window managers prefer small, square window icons.
        if icon_surface.get_width() > 128 or icon_surface.get_height() > 128:
            icon_surface = pg.transform.smoothscale(icon_surface, (64, 64))
        pg.display.set_icon(icon_surface)
        logger.info("Set window icon from %s", icon_path)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not set window icon from %s: %s", icon_path, exc)


class Engine:
    def __init__(self, renderer: Renderer, gui_renderer: Renderer) -> None:
        self.renderer: Renderer = renderer
        self.gui_renderer: Renderer = gui_renderer
        self._active_renderer: Renderer = self.renderer
        self.room_width: float
        self.room_height: float
        self.room_speed: float
        self.room_background_color: pg.Color
        self.room: int = 0
        self.delta_time: float
        self.fps_real: float

        self.room_set_size(
            view.view_wport[view.view_current], view.view_hport[view.view_current]
        )
        self.game_set_speed(60)
        self.room_set_background(Color(0, 0, 0))

        self._clock: pg.time.Clock = pg.time.Clock()
        self._last_render_time: float = 0
        self._game_objects: dict[UUID, IGameObject] = {}
        self._game_objects_to_destroy: set[IGameObject] = set()
        self._game_objects_to_add: list[IGameObject] = []
        self._game_running: bool = False
        self._object_registry: dict[str, type[IGameObject]] = {}
        self._spatial_index: pyqtree.Index | None = None

        self._rooms: list[GameLevel] = []
        self._audio_playing: list[GameSound] = []

        self._logger: Logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.DEBUG)

    def set_rooms(self, rooms: list[GameLevel]) -> None:
        if len(rooms) == 0:
            raise ValueError("At least one room must be provided to start the game.")
        self._rooms = rooms
        self.room_set_size(*rooms[0].level_size)

    def register_objects(self, *objects: type[IGameObject]) -> None:
        for obj in objects:
            self._object_registry[obj.__name__] = obj

    def room_goto(self, index: int) -> None:
        # Remove just the non-persistent instances
        for instance in self._game_objects.values():
            if not instance.persistent:
                self.instance_destroy(instance)

        level = self._rooms[index]

        self.room_set_size(*level.level_size)

        # Draw the level
        self.renderer.set_background_images(list(level.background_surfaces.values()))

        # Load the tilemaps
        for layer, tilemap in level.tilemaps.items():
            tile_size: tuple[int, int] = level.tile_sizes[layer]

            for y, row in enumerate(tilemap):
                for x, cell in enumerate(row):
                    if cell:
                        tile_cls = self._object_registry.get(layer)
                        if tile_cls is None:
                            raise ValueError(
                                f"{layer} object not found in registry. Make sure you "
                                + f"have registered it with `aj.register_objects({layer})`"
                            )
                        _ = cast(Callable[..., IGameObject], tile_cls)(
                            x * tile_size[0],
                            y * tile_size[1],
                            width=tile_size[0],
                            height=tile_size[1],
                        )

        # Load the entities
        for entity_type, entities in level.entities.items():
            for entity in entities:
                entity_cls = self._object_registry.get(entity_type)
                if entity_cls is None:
                    self._logger.warning(
                        "%s object not found in registry. Make sure you "
                        + "have registered it with `aj.register_objects(%s)`",
                        entity_type,
                        entity_type,
                    )
                    continue

                if not (self.instance_exists(entity_cls) and entity_cls.persistent):
                    _ = entity_cls.create_from_entity(entity)

        self.room = index

    def room_goto_next(self) -> None:
        self.room_goto(self.room + 1)

    def room_goto_previous(self) -> None:
        self.room_goto(self.room - 1)

    def room_restart(self) -> None:
        self.room_goto(self.room)

    def game_restart(self) -> None:
        for obj in self._game_objects.values():
            self.instance_destroy(obj)
        if len(self._rooms) > 0:
            self.room_goto(0)

    def game_end(self) -> None:
        self._game_running = False
        for obj in self._game_objects.values():
            obj.on_game_end()

    def game_set_speed(self, speed: float) -> None:
        self.room_speed = speed
        if speed != 0:
            self.delta_time = 1 / self.room_speed  # seconds

    def _get_obj_aabb(
        self, obj: IGameObject
    ) -> tuple[float, float, float, float] | None:
        """Return (left, top, right, bottom) world AABB for obj, or None if no collision mask."""
        msk = obj.collision_mask
        if msk is None:
            return None
        return (
            obj.x + msk.bbleft,
            obj.y + msk.bbtop,
            obj.x + msk.bbright,
            obj.y + msk.bbbottom,
        )

    def _rebuild_spatial_index(self) -> None:
        margin = 2_000.0
        bounds = (-margin, -margin, self.room_width + margin, self.room_height + margin)
        self._spatial_index = pyqtree.Index(bbox=bounds)

        def is_inside(rect: tuple[float, float, float, float]) -> bool:
            lf, tp, rt, bm = rect
            bl, bt, br, bb = bounds
            return lf >= bl and rt <= br and tp >= bt and bm <= bb

        for obj in self._game_objects.values():
            if obj in self._game_objects_to_destroy:
                continue
            aabb = self._get_obj_aabb(obj)
            if aabb is not None and is_inside(aabb):
                self._spatial_index.insert(obj, aabb)  # pyright: ignore[reportUnknownMemberType]

        for obj in self._game_objects_to_add:
            aabb = self._get_obj_aabb(obj)
            if aabb is not None and is_inside(aabb):
                self._spatial_index.insert(obj, aabb)  # pyright: ignore[reportUnknownMemberType]

    def collision_rectangle_list(
        self, left: float, top: float, right: float, bottom: float
    ) -> list[IGameObject]:
        """
        This function checks a rectangular area for a collision with all instances. It returns the
        list of all instances in the supplied rectangular region.

        This function is the same as the collision_rectangle() function, only instead of just
        detecting one instance at a time, it will detect multiple instances. You supply the x/y
        positions of the top left and bottom right of the area to check.
        """
        if self._spatial_index is None:
            return []
        # RectQuadTreeObjects.query returns a list of objects directly
        return cast(
            list[IGameObject],
            self._spatial_index.intersect((left, top, right, bottom)),  # pyright: ignore[reportUnknownMemberType]
        )

    def window_set_size(self, w: int, h: int) -> None:
        view.window_set_size(w, h)
        self.renderer.set_screen_size(w, h)
        # viewport was also synced to window by view.window_set_size, so re-create surface
        self.renderer.fit_display()

    def view_set_wport(self, view_idx: int, w: float) -> None:
        view.view_set_wport(view_idx, w)

    def view_set_hport(self, view_idx: int, h: float) -> None:
        view.view_set_hport(view_idx, h)

    def view_set_xport(self, view_idx: int, x: float) -> None:
        view.view_set_xport(view_idx, x)

    def view_set_yport(self, view_idx: int, y: float) -> None:
        view.view_set_yport(view_idx, y)

    def room_set_size(self, w: float, h: float) -> None:
        self.room_width = w
        self.room_height = h

    def room_set_width(self, w: int) -> None:
        self.room_set_size(w, self.room_height)

    def room_set_height(self, h: int) -> None:
        self.room_set_size(self.room_width, h)

    def room_set_background(self, color: pg.Color) -> None:
        self.room_background_color = color

    def audio_play_sound(
        self, index: GameSound, loop: bool = False, gain: float = 1
    ) -> None:
        self._audio_playing.append(index)
        index.play(loop=loop, gain=gain)

    def audio_is_playing(self, index: GameSound) -> bool:
        return index in self._audio_playing

    def add_object(self, obj: IGameObject) -> None:
        self._game_objects_to_add.append(obj)

    def instance_destroy(self, obj: IGameObject) -> None:
        obj.on_destroy()
        self._game_objects_to_destroy.add(obj)

    def instance_count(self, obj: type[IGameObject]) -> int:
        count: int = 0
        all_objects = list(self._game_objects.values()) + self._game_objects_to_add
        for g_o in all_objects:
            if isinstance(g_o, obj) and g_o not in self._game_objects_to_destroy:
                count += 1
        return count

    def instance_exists(self, obj: type[IGameObject]) -> bool:
        return self.instance_count(obj) > 0

    def instance_find(
        self, obj: type[IGameObject] | str, n: int = 0
    ) -> IGameObject | None:
        all_objects = list(self._game_objects.values()) + self._game_objects_to_add

        if isinstance(obj, str):
            for g_o in all_objects:
                if g_o.iid == obj and g_o not in self._game_objects_to_destroy:
                    return g_o
            return None

        count: int = 0
        for g_o in all_objects:
            if isinstance(g_o, obj) and g_o not in self._game_objects_to_destroy:
                if count == n:
                    return g_o
                count += 1
        return None

    def instance_position(
        self, x: float, y: float, obj: IGameObject | type[IGameObject] | str
    ) -> IGameObject | None:
        """
        With this function you can check a position for a collision with another instance or all
        instances of an object. When you use this you are checking a single point in the room for an
        instance or an object. This check will be done against the collision mask of the instance
        and will return the unique instance id. This function will return `None` if no collision
        occurs, or the exact instance found if a collision does occur.
        """

        if isinstance(obj, IGameObject):
            if obj in self._game_objects_to_destroy or obj.collision_mask is None:
                return None

            msk = obj.collision_mask
            if (
                obj.x + msk.bbleft <= x <= obj.x + msk.bbright
                and obj.y + msk.bbtop <= y <= obj.y + msk.bbbottom
            ):
                return obj

        if isinstance(obj, str):
            target = self.instance_find(obj)
            if target is None:
                return None
            return self.instance_position(x, y, target)

        if isinstance(obj, type):
            # Create a tiny rectangle around the point
            query_rect = (x - epsilon, y - epsilon, x + epsilon, y + epsilon)
            candidates = self.collision_rectangle_list(*query_rect)
            for g_o in candidates:
                if g_o in self._game_objects_to_destroy or g_o.collision_mask is None:
                    continue
                if isinstance(g_o, obj):
                    msk = g_o.collision_mask
                    if (
                        g_o.x + msk.bbleft <= x <= g_o.x + msk.bbright
                        and g_o.y + msk.bbtop <= y <= g_o.y + msk.bbbottom
                    ):
                        return g_o
            return None

        return None

    def collision_rectangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        obj: IGameObject | type[IGameObject] | UUID,  # FIXME: Shouldn't this be `str`?
        not_these: Container[IGameObject] | None = None,
    ) -> IGameObject | None:
        """
        This function checks a rectangular area for a collision with the given instance or
        instances of the given object, and returns the first result found.

        You may also choose to supply any special instances that are excluded from collision checks.

        This function will return the unique id of the instance being collided with. If no
        collisions are found, noone is returned.
        """
        left, right = (x1, x2) if x1 < x2 else (x2, x1)
        top, bottom = (y1, y2) if y1 < y2 else (y2, y1)

        if isinstance(obj, type):
            candidates = self.collision_rectangle_list(left, top, right, bottom)
            for g_o in candidates:
                if not_these is not None and g_o in not_these:
                    continue
                if isinstance(g_o, obj):
                    # precise check (reuse the concrete instance branch)
                    if self.collision_rectangle(
                        left, top, right, bottom, g_o, not_these
                    ):
                        return g_o
            return None

        if isinstance(obj, UUID):
            game_obj = self.get_game_object_by_id(obj)
            if game_obj is None:
                return None
            return self.collision_rectangle(
                left, top, right, bottom, game_obj, not_these
            )

        if not_these is not None and obj in not_these:
            return None

        o = obj
        o_msk: CollisionMask | None = o.collision_mask

        if o_msk is None:
            return None

        if (
            left < obj.x + o_msk.bbright
            and right > obj.x + o_msk.bbleft
            and top < obj.y + o_msk.bbbottom
            and bottom > obj.y + o_msk.bbtop
        ):
            return o
        return None

    def _begin_game_session(self) -> None:
        if len(self._rooms) > 0:
            self.room_goto(0)
        self._game_running = True

    def _run_game_iteration(self) -> bool:
        input.events += pg.event.get()

        if any(event.type == pg.QUIT for event in input.events):
            self.game_end()

        self.delta_time = self._clock.tick(self.room_speed) / 1000
        self.fps_real = self._clock.get_fps()

        if self.room_speed == 0:
            return False

        self._last_render_time += self.delta_time
        if self._last_render_time >= 1 / self.room_speed:
            self._last_render_time %= 1 / self.room_speed

            # Clear and prepare world renderer
            self._active_renderer = self.renderer
            self.renderer.fit_display()
            self.renderer.fill_background_color(self.room_background_color)
            self.renderer.draw_background_images()

            self._add_pending_objects()
            self._free_destroyed_objects()
            self._rebuild_spatial_index()

            # Step pass
            for obj in self._game_objects.values():
                obj.step()

            self.gui_renderer.display = pg.Surface((view.window_width, view.window_height), pg.SRCALPHA)

            draw_buffer = sorted(
                self._game_objects.values(),
                key=lambda obj: obj.depth,
                reverse=True,
            )

            # World Draw Pass
            for obj in draw_buffer:
                obj.draw()

            self.renderer.draw_display()

            # GUI Draw pass
            _ = self.gui_renderer.display.fill((0, 0, 0, 0))

            self._active_renderer = self.gui_renderer
            for obj in draw_buffer:
                obj.draw_gui()

            # self.renderer._screen.blit(self.gui_renderer.display, (0, 0))
            self.gui_renderer.draw_display()
            pg.display.update()

            # Reset active renderer back to standard world renderer for next frame logic
            self._active_renderer = self.renderer

            # Input cleanup
            input.prev_events = input.events.copy()
            input.events.clear()

        self._audio_playing = [
            audio
            for audio in self._audio_playing
            if not audio.is_finished(self.delta_time)
        ]
        return True

    def game_start(self) -> None:
        self._begin_game_session()
        while self._game_running:
            try:
                _ = self._run_game_iteration()

            except KeyboardInterrupt:
                self._game_running = False

        pg.quit()
        sys.exit()

    async def game_start_async(self) -> None:
        """Async version of game_start for pygbag/WASM compatibility.
        Yields control to the browser event loop every frame."""
        self._begin_game_session()
        while self._game_running:
            try:
                _ = self._run_game_iteration()

            except KeyboardInterrupt:
                self._game_running = False

            await asyncio.sleep(0)

        pg.quit()

    def get_game_objects(self) -> Iterable[IGameObject]:
        return self._game_objects.values()

    def get_game_object_by_id(self, id: UUID) -> IGameObject | None:
        return self._game_objects.get(id)

    def instances_iterate(self, obj: type[IGameObject]) -> Iterable[IGameObject]:
        """
        With this function you can iterate over all instances of an object. This is especially
        useful for doing something to all instances of an object in a loop.
        """
        all_objects = list(self._game_objects.values()) + self._game_objects_to_add
        for g_o in all_objects:
            if g_o in self._game_objects_to_destroy:
                continue
            if isinstance(g_o, obj):
                yield g_o

    @property
    def mouse_x(self) -> float:
        return pg.mouse.get_pos()[0]

    @property
    def mouse_y(self) -> float:
        return pg.mouse.get_pos()[1]

    @property
    def mouse_room_x(self) -> float:
        """Mouse x in room coordinates, accounting for window scaling and the view."""
        return self.renderer.window_to_room(*pg.mouse.get_pos())[0]

    @property
    def mouse_room_y(self) -> float:
        """Mouse y in room coordinates, accounting for window scaling and the view."""
        return self.renderer.window_to_room(*pg.mouse.get_pos())[1]

    def _free_destroyed_objects(self) -> None:
        for obj in self._game_objects_to_destroy:
            try:
                _ = self._game_objects.pop(obj.id)
            except KeyError:
                pass
        self._game_objects_to_destroy.clear()

    def _add_pending_objects(self) -> None:
        for obj in self._game_objects_to_add:
            self._game_objects[obj.id] = obj
        self._game_objects_to_add.clear()

    # Thin wrappers for the proper implementations in rendering.py - only thing this'll do is choose the correct renderer
    def draw_set_color(self, color: Color) -> None:
        self._active_renderer.draw_set_color(color)

    def draw_set_circle_precision(self, precision: int) -> None:
        self._active_renderer.draw_set_circle_precision(precision)

    def draw_circle(
        self,
        x: float,
        y: float,
        r: float,
        outline: bool = False,
        color: Color | None = None,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_circle(
            x, y, r, outline=outline, color=color, alpha=alpha
        )

    def draw_ellipse(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        outline: bool = False,
        color: Color | None = None,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_ellipse(
            x1, y1, x2, y2, outline=outline, color=color, alpha=alpha
        )

    def draw_rectangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        outline: bool = False,
        color: Color | None = None,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_rectangle(
            x1, y1, x2, y2, outline=outline, color=color, alpha=alpha
        )

    def draw_triangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        x3: float,
        y3: float,
        col1: Color | None = None,
        col2: Color | None = None,
        col3: Color | None = None,
        outline: bool = False,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_triangle(
            x1,
            y1,
            x2,
            y2,
            x3,
            y3,
            col1=col1,
            col2=col2,
            col3=col3,
            outline=outline,
            alpha=alpha,
        )

    def draw_point(
        self, x: float, y: float, color: Color | None = None, alpha: float = 1.0
    ) -> None:
        self._active_renderer.draw_point(x, y, color=color, alpha=alpha)

    def draw_line(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        color: Color | None = None,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_line(x1, y1, x2, y2, color=color, alpha=alpha)

    def draw_text(
        self, x: float, y: float, string: str, color: Color | None = None
    ) -> None:
        self._active_renderer.draw_text(x, y, string, color=color)

    def draw_sprite(
        self,
        x: float,
        y: float,
        sprite_index: GameSprite,
        image_index: int,
        x_scale: float = 1.0,
        y_scale: float = 1.0,
        rotation: float = 0.0,
        color: Color = c_white,
        alpha: float = 1.0,
    ) -> None:
        self._active_renderer.draw_sprite(
            x,
            y,
            sprite_index,
            image_index,
            x_scale=x_scale,
            y_scale=y_scale,
            rotation=rotation,
            color=color,
            alpha=alpha,
        )

    def draw_set_font(
        self, font: pg.font.Font, fallbacks: Iterable[pg.font.Font] | None = None
    ) -> None:
        self._active_renderer.draw_set_font(font, fallbacks=fallbacks)

    def text_width(self, string: str) -> int:
        return self._active_renderer.text_width(string)

    def text_height(self, string: str) -> int:
        return self._active_renderer.text_height(string)
